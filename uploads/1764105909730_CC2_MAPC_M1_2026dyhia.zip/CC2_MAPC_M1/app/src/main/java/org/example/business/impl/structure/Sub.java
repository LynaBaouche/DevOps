package org.example.business.impl.structure;

import org.example.business.api.Expression;
import org.example.business.api.VisiteurExpression;

public class Sub implements Expression {

    private final Expression gauche;
    private final Expression droite;

    public Sub(Expression gauche, Expression droite) {
        this.gauche = gauche;
        this.droite = droite;
    }

    @Override
    public Object valeur() {
        Integer vg = (Integer) gauche.valeur();
        Integer vd = (Integer) droite.valeur();
        return vg - vd;
    }

    public Expression getGauche() { return gauche; }
public Expression getDroite() { return droite; }


        @Override
    public <R> R accepter(VisiteurExpression<R> visiteur) {
        return visiteur.visiterSub(this);
    }

    @Override
    public String toString() {
        return "sub(" + gauche + ", " + droite + ")";
    }
}
