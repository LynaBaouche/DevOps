package org.example.business.api;

import org.example.business.impl.structure.*;
import org.example.business.impl.visiteurs.*;
import org.example.business.api.*; 


public interface VisiteurExpression<R> {

    R visiterNombre(Nombre n);

    R visiterBooleen(Booleen b);

    R visiterInf(Inf op);

    R visiterConjonction(Conjonction op);

    R visiterSub(Sub op);

    R visiterMin(Min op);

    R visiterMax(Max op);

    // ⭐⭐ C’EST CETTE MÉTHODE QUI MANQUE CHEZ TOI ⭐⭐
    R visiterSiAlorsSinon(SiAlorsSinon op);
}
