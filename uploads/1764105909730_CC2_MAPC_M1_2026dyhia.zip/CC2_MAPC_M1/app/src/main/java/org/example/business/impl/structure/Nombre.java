package org.example.business.impl.structure;


import org.example.business.api.Expression;
import org.example.business.api.VisiteurExpression;

public class Nombre implements Expression {

    private final int valeur;

    
    Nombre(int valeur) {
        this.valeur = valeur;
    }

    int getValeur() {
        return valeur;
    }

    @Override
    public Object valeur() {
        return valeur;
    }

        @Override
    public <R> R accepter(VisiteurExpression<R> visiteur) {
        return visiteur.visiterNombre(this);
    }

    @Override
    public String toString() {
        return Integer.toString(valeur);
    }
}
