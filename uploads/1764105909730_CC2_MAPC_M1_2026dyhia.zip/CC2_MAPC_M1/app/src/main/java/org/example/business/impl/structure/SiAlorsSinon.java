package org.example.business.impl.structure;


import org.example.business.api.Expression;
import org.example.business.api.VisiteurExpression;


public class SiAlorsSinon implements Expression {

    private final Expression condition;
    private final Expression alorsExpression;
    private final Expression sinonExpression;

    public SiAlorsSinon(Expression condition,
                        Expression alorsExpression,
                        Expression sinonExpression) {
        this.condition = condition;
        this.alorsExpression = alorsExpression;
        this.sinonExpression = sinonExpression;
    }

    // ➜ GETTERS OBLIGATOIRES POUR LE VISITEUR
    public Expression getCondition() {
        return condition;
    }

    public Expression getAlorsExpression() {
        return alorsExpression;
    }

    public Expression getSinonExpression() {
        return sinonExpression;
    }

    @Override
    public Object valeur() {
        Boolean cond = (Boolean) condition.valeur();
        return cond ? alorsExpression.valeur() : sinonExpression.valeur();
    }

    @Override
    public <R> R accepter(VisiteurExpression<R> visiteur) {
        return visiteur.visiterSiAlorsSinon(this);
    }
    

    @Override
    public String toString() {
        return "si (" + condition + ")\n"
             + "alors " + alorsExpression + "\n"
             + "sinon " + sinonExpression;
    }
}
