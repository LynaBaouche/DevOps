package org.example.business.impl.visiteurs;


import org.example.business.api.VisiteurExpression;

import org.example.business.impl.structure.*;


public class VisiteurComplexite implements VisiteurExpression<Integer> {

    @Override
    public Integer visiterNombre(Nombre n) {
        return 0;
    }

    @Override
    public Integer visiterBooleen(Booleen b) {
        return 0;
    }

    @Override
    public Integer visiterInf(Inf op) {
        return 1
                + op.getGauche().accepter(this)
                + op.getDroite().accepter(this);
    }

    @Override
    public Integer visiterConjonction(Conjonction op) {
        return 1
                + op.getGauche().accepter(this)
                + op.getDroite().accepter(this);
    }

    @Override
    public Integer visiterSub(Sub op) {
        return 1
                + op.getGauche().accepter(this)
                + op.getDroite().accepter(this);
    }

    @Override
    public Integer visiterMin(Min op) {
        return 1
                + op.getGauche().accepter(this)
                + op.getDroite().accepter(this);
    }

    @Override
    public Integer visiterMax(Max op) {
        return 1
                + op.getGauche().accepter(this)
                + op.getDroite().accepter(this);
    }

    @Override
    public Integer visiterSiAlorsSinon(SiAlorsSinon op) {
        return 3+ op.getCondition().accepter(this)+ op.getAlorsExpression().accepter(this)+ op.getSinonExpression().accepter(this);
    }
}
