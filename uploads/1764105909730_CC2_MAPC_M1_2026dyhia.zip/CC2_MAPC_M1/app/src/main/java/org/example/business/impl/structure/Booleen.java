package org.example.business.impl.structure;


import org.example.business.api.Expression;
import org.example.business.api.VisiteurExpression;

public class Booleen implements Expression {

    public static final Booleen VRAI = new Booleen(true);
    public static final Booleen FAUX = new Booleen(false);

    private final boolean valeur;

    private Booleen(boolean valeur) {
        this.valeur = valeur;
    }

    public static Booleen valeurDe(boolean valeur) {
        return valeur ? VRAI : FAUX;
    }

    @Override
    public Object valeur() {
        return valeur;
    }
        @Override
    public <R> R accepter(VisiteurExpression<R> visiteur) {
        return visiteur.visiterBooleen(this);
    }

    @Override
    public String toString() {
        return valeur ? "vrai" : "faux";
    }
}


