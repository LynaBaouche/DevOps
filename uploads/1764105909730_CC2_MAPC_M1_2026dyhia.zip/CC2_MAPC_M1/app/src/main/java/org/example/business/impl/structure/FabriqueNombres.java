package org.example.business.impl.structure;

//import org.example.business.api.Expression;
import java.util.HashMap;
import java.util.Map;

/**
 * Flyweight pour les nombres : une seule instance par valeur entière.
 */
public final class FabriqueNombres {

    private static final Map<Integer, Nombre> CACHE = new HashMap<>();

    private FabriqueNombres() {
        // rien
    }

    public static Nombre getNombre(int valeur) {
        return CACHE.computeIfAbsent(valeur, Nombre::new);
    }
}
