package org.example.business.impl.structure;

import org.example.business.api.Expression;
import org.example.business.api.VisiteurExpression;

public class Max implements Expression {

    private final Expression gauche;
    private final Expression droite;

    public Max(Expression gauche, Expression droite) {
        this.gauche = gauche;
        this.droite = droite;
    }

    public Expression getGauche() { return gauche; }
public Expression getDroite() { return droite; }


    @Override
    public Object valeur() {
        Integer vg = (Integer) gauche.valeur();
        Integer vd = (Integer) droite.valeur();
        return Math.max(vg, vd);
    }

    @Override
    public <R> R accepter(VisiteurExpression<R> visiteur) {
        return visiteur.visiterMax(this);
    }

    @Override
    public String toString() {
        return "max(" + gauche + ", " + droite + ")";
    }
}

