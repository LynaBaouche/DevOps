package org.example.business.api;

import org.example.business.impl.structure.*;
import org.example.business.impl.visiteurs.*;
import org.example.business.api.*; 


public interface Expression {
    Object valeur();

    //pr la parti 2 visiteuur 
    <R> R accepter(VisiteurExpression<R> visiteur);
}
